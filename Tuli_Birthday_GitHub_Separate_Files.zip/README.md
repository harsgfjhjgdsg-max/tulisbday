# Tuli Birthday Website

GitHub Pages ready. Upload the whole folder contents so `index.html` stays in the repository root.

```text
index.html
assets/
  tuli-music.mp3
  tulip-field.jpg
  tuli-photo-1.webp
  tuli-photo-2.webp
  tuli-photo-3.jpg
  tuli-photo-4.jpg
  tuli-photo-5.jpg
```

Then enable GitHub Pages from **Settings → Pages → Deploy from a branch → main → /(root)**.
